package com.tns.ShopOwnerService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopOwnerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
